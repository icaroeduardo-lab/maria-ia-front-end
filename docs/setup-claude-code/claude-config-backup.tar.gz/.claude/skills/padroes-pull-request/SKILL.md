---
name: padroes-pull-request
description: Estrutura de pull requests (título :emoji: tipo:, corpo com Closes #N e Como testar, destino develop, pt-BR). Usar SEMPRE que for abrir ou escrever um pull request em qualquer repositório do usuário.
---

# Padrões de pull request

Se o repositório tiver `docs/padroes-pull-request.md`, ele é a versão completa e prevalece.

## Regras gerais

- Destino padrão: `develop` (`hotfix/*` → `main`).
- Um PR = uma issue; pequeno e focado.
- Idioma: pt-BR (título e corpo).
- CI passando antes do merge; merge preferencial squash; apagar branch depois.

## Título

Mesmo formato dos commits (skill `padroes-commits`):

```
:emoji: tipo: Descrição curta e objetiva
```

Ex: `:sparkles: feat: Cliente HTTP com token por env`

## Corpo (template obrigatório)

```markdown
## Resumo

O que este PR faz e por quê, em 1–3 frases.

## Issue relacionada

Closes #<numero>

## O que foi feito

- Mudança 1
- Mudança 2

## Como testar

Passos objetivos para o revisor validar.

## Observações (opcional)

Decisões, débitos assumidos, prints.
```

- `Closes #N` / `Fixes #N` para fechar a issue no merge.
- "Como testar" obrigatório quando há mudança de comportamento visível.

## Checklist antes de abrir

Branch conforme `padroes-branch` · título `:emoji: tipo:` · `Closes #N` · typecheck/lint passando · critérios de aceitação da issue atendidos · sem segredos no diff.
